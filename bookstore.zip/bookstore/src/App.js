import { BrowserRouter as Router, Routes, Route, } from 'react-router-dom';
import './App.css';
import Login from './Pages/Login.Component';
import Home from './Pages/Home';
import Cart from './Pages/Cart';


function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path='/' element={<Home  />} />
        </Routes>
        <Routes>
          <Route path='/login' element={<Login />} />
        </Routes>
        <Routes>
          <Route path='/cart' element={<Cart />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;