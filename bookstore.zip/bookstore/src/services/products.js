import watchImage from '../images/watch.webp';
import macImage from '../images/mac.jpeg';
import samsungImage from '../images/samsung.jpeg';

const Products = [
  {
    "id": 1,
    "title": "Smart Watch",
    "description": "An all rounded smart watch for your daily need",
    "price": 200,
    "image": watchImage
  },
  {
    "id": 2,
    "title": "Macbook Pro",
    "description": "The M3 Pro Macbook for top devs",
    "price": 3000,
    "image": macImage
  },
  {
    "id": 3,
    "title": "Samsung S24 Ultra",
    "description": "The op end flagship Samsung phone on the market",
    "price": 2000,
    "image": samsungImage
  },
  {
    "id": 1,
    "title": "Smart Watch",
    "description": "An all rounded smart watch for your daily need",
    "price": 200,
    "image": watchImage
  },
  {
    "id": 2,
    "title": "Macbook Pro",
    "description": "The M3 Pro Macbook for top devs",
    "price": 3000,
    "image": macImage
  },
  {
    "id": 3,
    "title": "Samsung S24 Ultra",
    "description": "The op end flagship Samsung phone on the market",
    "price": 2000,
    "image": samsungImage
  }
];

export default Products;