import CartItem from "../Components/cart/cart.component";

const Cart = () => {
    <div>
        <CartItem />
    </div>
}


export default Cart;