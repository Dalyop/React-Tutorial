
const title = "My React App";

function Login() {
    return (
        <form>
            <h1>{}</h1>
            <input type="email" placeholder="johndoe@gmail.com"></input>
            <input type="password" placeholder="********"></input>
            <button type="submit">Login</button>
        </form>
    )
}

export default Login;