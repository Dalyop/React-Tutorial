import Navbar from "../Components/Navbar.Component";
import Product from "../Components/Product/product.component";
import Products from "../services/products";


function Home() {
    return (
        <div>
            <Navbar />
           <Product />
        </div>
    )
}
export default Home;