const Items = (props) => {
    <div>
        <h1>
            {props.name}
        </h1>
    </div>
}

function CartItem() {
    return (
        <Items />
    )
}

<Items name = "Iphone" /> 

export default CartItem;