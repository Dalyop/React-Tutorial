import "./product.component.css";
import Products from "../../services/products";

function Product() {
    return (
        <div className="product">
            {Products.map(product => (
                <div key={product.id} className="cont">
                    <div className="product-card">
                        <div className="product-card__image">
                            <img src={product.image} alt={product.title} />
                        </div>
                        <div className="product-card__info">
                            <h2 className="product-card__title">{product.title}</h2>
                            <p className="product-card__description">{product.description}</p>
                            <div className="product-card__price-row">
                                <span className="product-card__price">${product.price}</span>
                                <button className="product-card__btn">Add to Cart</button>
                            </div>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    )
}

export default Product;