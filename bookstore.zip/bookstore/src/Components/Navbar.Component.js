import { Nav, Anchor, Bar } from "./Navbar.Styled";
import { Link } from "react-router-dom";

function Navbar() {
    return (
        <Nav>
            <div className="brand">
                <h2>Swayed</h2>
            </div>
            <div className="links">
                <Anchor>Shop</Anchor>
                <Link to='/cart'>
                <Anchor>Checkout</Anchor>
                </Link>
                <Link to='/login'>
                <Anchor>Login</Anchor>
                </Link>
            </div>
            <div className="icon">
                <Bar></Bar>
                <Bar></Bar>
                <Bar></Bar>
            </div>
        </Nav>
    )
}

export default Navbar;