import styled from "styled-components";

const Nav = styled.nav`
background-color: black;
color: white;
display: flex;
justify-content: space-between;
align-items: center;    
padding: 1em;
`;

const Anchor = styled.a `
font-size: 1em;
font-weight: bold;
color: gold;
padding: 0.5em;
cursor: pointer;
`;

const Bar = styled.div`
width: 25px;
height: 3px;
margin: 5px;
background-color: white;
`

export {Nav, Anchor, Bar};